#include <iostream>
using namespace std;
int purchase=0;
void ask();
void display();

struct customer{
string items;
int quantity;
int amount;
}c[45];

int snacks()
{
int op;
   cout<<"1.Biscuits\n2.Chocolates\n3.chips\n";
   cin>>op;
    switch(op)
    {
    case 1:
        int opp;
        cout<<"Choose it\n1.DarkFantasy-30\n2.ParleG-5\n3.Unibic-10\n";
        cin>>opp;
        switch(opp)
        {
        case 1:
            {
        c[1].items="DarkFantasy";
        int countt;
        int df=30;
        cout<<"Enter the count:\n";
        cin>>countt;
        c[1].quantity=countt;
        countt=countt*df;
        c[1].amount=countt;
        purchase+=countt;
        ask();
        break;
        }
        case 2:
            {
            c[2].items="ParleG";
            int G;
            int pg=5;
            cout<<"Enter the count:\n";
            cin>>G;
            c[2].quantity=G;
            G=G*pg;
            c[2].amount=G;
            purchase+=G;
            ask();
            break;
            }
case 3:
            {
            c[3].items="Unibic";
            int cc;
            int Ub=10;
            cout<<"Enter the count:\n";
            cin>>cc;
            c[3].quantity=cc;

            cc=cc*Ub;
            c[3].amount=cc;

            purchase+=cc;
            ask();
            break;
            }

        }
    }
 switch(op)
  {
 case 2:
     int opp1;
     cout<<"choose it\n1.fivestar-10\n2.dairymilk-5\n3.milkybar-10\n";
     cin>>opp1;
 switch(opp1)
 {
   case 1 :
       {
        c[4].items="fivestar";
        int chlt;
        int fs=10;
        cout<<"enter the count:\n";
        cin>>chlt;
        c[4].quantity=chlt;
        chlt=chlt*fs;
        c[4].amount=chlt;

        purchase+=chlt;
        ask();
        break;
   }
   case 2:
    {
        c[5].items="dairymilk";
        int chlt1;
        int dm=5;
        cout<<"enter the count:\n";
        cin>>chlt1;
        c[5].quantity=chlt1;
        chlt1=chlt1*dm;
        c[5].amount=chlt1;

        purchase+=chlt1;
        ask();
        break;
    }
     case 3:
    {
        c[6].items="milkybar";
        int chlt2;
        int mb=10;
        cout<<"enter the count:\n";
        cin>>chlt2;
        c[6].quantity=chlt2;
        chlt2=chlt2*mb;
        c[6].amount=chlt2;
        purchase+=chlt2;
        ask();
        break;
    }
 }

 }
 switch (op)
 {
  case 3:
        int opp2;
        cout<<"Choose it\n1.lays-10\n2.bingo-5\n3.pringles-10\n";
        cin>>opp2;
        switch(opp2)
        {
        case 1:
            {
            c[7].items="lays";
            int Z;
            int lys=10;
            cout<<"Enter the count:\n";
            cin>>Z;
            c[7].quantity=Z;
            Z=Z*lys;
            c[7].amount=Z;

            purchase+=Z;
            ask();
            break;
            }
        case 2:
            {
            c[8].items="bingo";
            int c1;
            int bo=5;
            cout<<"Enter the count:\n";
            cin>>c1;
             c[8].quantity=c1;
            c1=c1*bo;
            c[8].amount=c1;

            purchase+=c1;
            ask();
            break;
            }
case 3:
            {
            c[9].items="pringles";
            int c2;
            int sp=10;
            cout<<"Enter the count:\n";
            cin>>c2;
             c[9].quantity=c2;
            c2=c2*sp;
            c[9].amount=c2;

            purchase+=c2;
            ask();
            break;
            }

        }
    }



}

int stationery()
{
int op;
   cout<<"1.pens\n2.pencils\n3.notebooks\n";
   cin>>op;
    switch(op)
    {
    case 1:
        int pns;
        cout<<"Choose it\n1.flairpen-60\n2.heropen-50\n3.camlinpen-30\n";
        cin>>pns;
        switch(pns)
        {
        case 1:
            {
            c[10].items="flairpen";
            int ss;
            int fp=60;
            cout<<"Enter the count:\n";
            cin>>ss;
            c[10].quantity=ss;
            ss=ss*fp;
            c[10].amount=ss;

            purchase+=ss;
            ask();
            break;
            }
        case 2:
            {
            c[11].items="heropen";
            int ss1;
            int hp=50;
            cout<<"Enter the count:\n";
            cin>>ss1;
            c[11].quantity=ss1;
            ss1=ss1*hp;
            c[11].amount=ss1;

            purchase+=ss1;
            ask();
            break;
            }
case 3:
            {
            c[12].items="campilnpen";
            int ss2;
            int cp=30;
            cout<<"Enter the count:\n";
            cin>>ss2;
            c[12].quantity=ss2;
            ss2=ss2*cp;
            c[12].amount=ss2;

            purchase+=ss2;
            ask();
            break;
            }

        }
    }
 switch(op)
  {
 case 2:
     int pnls;
     cout<<"choose it\n1.Nataraj-5\n2.Apsara-6\n3.Doms-5\n";
     cin>>pnls;
 switch(pnls)
 {
   case 1 :
       {
        c[13].items="Nataraj";
        int ps;
        int nj=5;
        cout<<"enter the count:\n";
        cin>>ps;
        c[13].quantity=ps;
        ps=ps*nj;
        c[13].amount=ps;
        purchase+=ps;
        ask();
        break;
   }
   case 2:
    {
        c[14].items="Apsara";
        int ps1;
        int apa=6;
        cout<<"enter the count:\n";
        cin>>ps1;
        c[14].quantity=ps1;
        ps1=ps1*apa;
        c[14].amount=ps1;
        purchase+=ps1;
        ask();
        break;
    }
     case 3:
    {
        c[15].items="Doms";
        int ps2;
        int ds=5;
        cout<<"enter the count:\n";
        cin>>ps2;
        c[15].quantity=ps2;
        ps2=ps2*ds;
        c[15].amount=ps2;
        purchase+=ps2;
        ask();
        break;
    }
 }

 }
 switch (op)
 {
  case 3:
        int n;
        cout<<"Choose it\n1.rulednote-30\n2.unrulednote-30\n3.graphnote-25\n";
        cin>>n;
        switch(n)
        {
        case 1:
            {
            c[16].items="rulednote";
            int n1;
            int r=30;
            cout<<"Enter the count:\n";
            cin>>n1;
            c[16].quantity=n1;
            n1=n1*r;
            c[16].amount=n1;

            purchase+=n1;
            ask();
            break;
            }
        case 2:
            {
            c[17].items="unrolednote";
            int n2;
            int ur=30;
            cout<<"Enter the count:\n";
            cin>>n2;
            c[17].quantity=n2;
            n2=n2*ur;
            c[17].amount=n2;
            purchase+=n2;
            ask();
            break;
            }
case 3:
            {
            c[18].items="graphnote";
            int n3;
            int gh=25;
            cout<<"Enter the count:\n";
            cin>>n3;
            c[18].quantity=n3;
            n3=n3*gh;
            c[18].amount=n3;
            purchase+=n3;
            ask();
            break;
            }

        }
    }

}
int cosmetics()
{
int op;
   cout<<"1.lipsticks\n2.Eyeliner\n3.Face Powder\n";
   cin>>op;
    switch(op)
    {
    case 1:
        int lips;
        cout<<"Choose it\n1.MAC-70\n2.Stilla-45\n3.Revlon-40\n";
        cin>>lips;
        switch(lips)
        {
        case 1:
            {
            c[19].items="MAC";
            int L;
            int MAC=70;
            cout<<"Enter the count:\n";
            cin>>L;
            c[19].quantity=L;
            L=L*MAC;
            c[19].amount=L;
            purchase+=L;
            ask();
            break;
            }
        case 2:
            {
            c[20].items="Stilla";
            int L1 ;
            int ST=45;
            cout<<"Enter the count:\n";
            cin>>L1;
            c[20].quantity=L1;
            L1=L1*ST;
            c[20].amount=L1;
            purchase+=L1;
            ask();
            break;
            }
case 3:
            {
            c[20].items="Revlon";
            int L2;
            int RE=40;
            cout<<"Enter the count:\n";
            cin>>L2;
            c[20].quantity=L2;
            L2=L2*RE;
            c[20].amount=L2;
            purchase+=L2;
            ask();
            break;
            }

        }
    }
 switch(op)
  {
 case 2:
     int eye;
     cout<<"choose it\n1.Dazller-50\n2.Lakme-120\n3.Maybeline New York-90\n";
     cin>>eye;
 switch(eye)
 {
   case 1 :
       {
        c[22].items="Dazller";
        int EE;
        int DA=50;
        cout<<"enter the count:\n";
        cin>>EE;
        c[22].quantity=EE;
        EE=EE*DA;
        c[22].amount=EE;
        purchase+=EE;
        ask();
        break;
   }
   case 2:
    {
        c[23].items="Lakme";
        int E1;
        int La=120;
        cout<<"enter the count:\n";
        cin>>E1;
        c[23].quantity=E1;
        E1=E1*La;
        c[23].amount=E1;
        purchase+=E1;
        ask();
        break;
    }
     case 3:
    {
        c[24].items="Mabeline New York";
        int E2;
        int MNY=90;
        cout<<"enter the count:\n";
        cin>>E2;
        c[24].quantity=E2;
        E2=E2*MNY;
        c[24].amount=E2;
        purchase+=E2;
        ask();
        break;
    }
 }

 }
 switch (op)
 {
  case 3:
        int fp;
        cout<<"Choose it\n1.Ponds-50\n2.WhiteTone-60\n3.Yardley-60\n";
        cin>>fp;
        switch(fp)
        {
        case 1:
            {
            c[25].items="Ponds";
            int FP1;
            int P=50;
            cout<<"Enter the count:\n";
            cin>>FP1;
            c[25].quantity=FP1;
            FP1=FP1*P;
            c[25].amount=FP1;
            purchase+=FP1;
            ask();
            break;
            }
        case 2:
            {
            c[26].items="WhiteTone";
            int FP2;
            int W=60;
            cout<<"Enter the count:\n";
            cin>>FP2;
            c[26].quantity=FP2;
            FP2=FP2*W;
            c[26].amount=FP2;
            purchase+=FP2;
            ask();
            break;
            }
case 3:
            {
            c[27].items="Yardley";
            int FP3;
            int Y=60;
            cout<<"Enter the count:\n";
            cin>>FP3;
            c[27].quantity=FP3;
            FP3=FP3*Y;
            c[27].amount=FP3;
            purchase+=FP3;
            ask();
            break;
            }

        }
    }

}

int groceries()
{
int op;
   cout<<"1.Dairy\n2.Vegetables\n3.Meat\n";
   cin>>op;
    switch(op)
    {
    case 1:
        int D;
        cout<<"Choose it\n1.Milk-50\n2.Curd-20\n3.Butter-60\n";
        cin>>D;
        switch(D)
        {
        case 1:
            {
            c[28].items="Milk";
            int D1;
            int MK=50;
            cout<<"Enter the count:\n";
            cin>>D1;
            c[28].quantity=D1;
            D1=D1*MK;
            c[28].amount=D1;
            purchase+=D1;
            ask();
            break;
            }
        case 2:
            {
            c[29].items="Curd";
            int D2;
            int CD=20;
            cout<<"Enter the count:\n";
            cin>>D2;
            c[29].quantity=D2;
            D2=D2*CD;
            c[29].amount=D2;

            purchase+=D2;
            ask();
            break;
            }
case 3:
            {
            c[30].items="Butter";
            int D3;
            int BTR=60;
            cout<<"Enter the count:\n";
            cin>>D3;
            c[30].quantity=D3;
            D3=D3*BTR;
            c[30].amount=D3;
            purchase+=D3;
            ask();
            break;
            }

        }
    }
 switch(op)
  {
 case 2:
     int V;
     cout<<"choose it\n1.Tomato(1Kg)-30\n2.Potato(1Kg)-40\carrot(1Kg)-70\n";
     cin>>V;
 switch(V)
 {
   case 1 :
       {
        c[31].items="Tomato";
        int VV;
        int TT=30;
        cout<<"enter the count:\n";
        cin>>VV;
        c[31].quantity=VV;
        VV=VV*TT;
        c[31].amount=VV;
        purchase+=VV;
        ask();
        break;
   }
   case 2:
    {
        c[32].items="Potato";
        int V1;
        int PT=40;
        cout<<"enter the count:\n";
        cin>>V1;
        c[32].quantity=V1;
        V1=V1*PT;
        c[32].amount=V1;
        purchase+=V1;
        ask();
        break;
    }
     case 3:
    {
        c[33].items="Carrot";
        int V2;
        int CT=70;
        cout<<"enter the count:\n";
        cin>>V2;
        c[33].quantity=V2;
        V2=V2*CT;
        c[33].amount=V2;
        purchase+=V2;
        ask();
        break;
    }
 }

 }
 switch (op)
 {
  case 3:
        int M;
        cout<<"Choose it\n1.Goat(1Kg)-800\n2.chicken(1Kg)-300\n3.fish(1Kg)-250\n";
        cin>>M;
        switch(M)
        {
        case 1:
            {
            c[34].items="Goat";
            int n11;
            int gt=800;
            cout<<"Enter the count:\n";
            cin>>n11;
            c[34].quantity=n11;
            n11=n11*gt;
            c[34].amount=n11;
            purchase+=n11;
            ask();
            break;
            }
        case 2:
            {
            c[35].items="chicken";
            int n22;
            int cn=300;
            cout<<"Enter the count:\n";
            cin>>n22;
            c[35].quantity=n22;
            n22=n22*cn;
            c[35].amount=n22;
            purchase+=n22;
            ask();
            break;
            }
case 3:
            {
            c[36].items="fish";
            int n33;
            int fs=250;
            cout<<"Enter the count:\n";
            cin>>n33;
            c[36].quantity=n33;
            n33=n33*fs;
            c[36].amount=n33;
            purchase+=n33;
            ask();
            break;
            }

        }
    }



}

int others()
{
int op;
   cout<<"1.Beverages\n2.Dried Fruits\n3.Ice-Cream\n";
   cin>>op;
    switch(op)
    {
    case 1:
        int bb;
        cout<<"Choose it\n1.maaza(500)-35\n2.sprite(500ml)-30\n3.slice(1 liter)-80\n";
        cin>>bb;
        switch(bb)
        {
        case 1:
            {
            c[37].items="maaza";
            int mm;
            int m=35;
            cout<<"Enter the count:\n";
            cin>>mm;
            c[37].quantity=mm;
            mm=mm*m;
            c[37].amount=mm;
            purchase+=mm;
            ask();
            break;
            }
        case 2:
            {
            c[38].items="sprite";
            int m1;
            int s=30;
            cout<<"Enter the count:\n";
            cin>>m1;
            c[38].quantity=m1;
            m1=m1*s;
            c[38].amount=m1;
            purchase+=m1;
            ask();
            break;
            }
case 3:
            {
            c[39].items="slice";
            int m2;
            int sl=80;
            cout<<"Enter the count:\n";
            cin>>m2;
            c[39].quantity=m2;
            m2=m2*sl;
            c[39].amount=m2;
            purchase+=m2;
            ask();
            break;
            }

        }
    }
 switch(op)
  {
 case 2:
     int bb1;
     cout<<"choose it\n1.Dates(1KG)-300\n2.Almonds(500g)-400\n3.Pista(500g)-500\n";
     cin>>bb1;
 switch(bb1)
 {
   case 1 :
       {
        c[40].items="Dates";
        int DD;
        int D=300;
        cout<<"enter the count:\n";
        cin>>DD;
        c[40].quantity=DD;
        DD=DD*D;
        c[40].amount=DD;
        purchase+=DD;
        ask();
        break;
   }
   case 2:
    {
        c[41].items="Almonds";
        int AA;
        int AS=400;
        cout<<"enter the count:\n";
        cin>>AA;
        c[41].quantity=AA;
        AA=AA*AS;
        c[41].amount=AA;
        purchase+=AA;;
        ask();
        break;
    }
     case 3:
    {
        c[42].items="Pista";
        int PP;
        int PA=500;
        cout<<"enter the count:\n";
        cin>>PP;
        c[42].quantity=PP;
        PP=PP*PA;
        c[42].amount=PP;
        purchase+=PP;
        ask();
        break;
    }
 }

 }
 switch (op)
 {
  case 3:
        int II;
        cout<<"Choose it\n1.cup ice-10\n2.cone ice-30\n3.stick ice-20\n";
        cin>>II;
        switch(II)
        {
        case 1:
            {
            c[43].items="cup ice";
            int ii;
            int ci=10;
            cout<<"Enter the count:\n";
            cin>>ii;
            c[43].quantity=ii;
            ii=ii*ci;
            c[43].amount=ii;
            purchase+=ii;
            ask();
            break;
            }
        case 2:
            {
            c[44].items="cone ice";
            int ii2;
            int i2=30;
            cout<<"Enter the count:\n";
            cin>>ii2;
            c[44].quantity=ii2;
            ii2=ii2*i2;
            c[44].amount=ii2;
            purchase+=ii2;
            ask();
            break;
            }
case 3:
            {
            c[45].items="stick ice";
            int ii3;
            int si=20;
            cout<<"Enter the count:\n";
            cin>>ii3;
            c[45].quantity=ii3;
            ii3=ii3*si;
            c[45].amount=ii3;
            purchase+=ii3;
            ask();
            break;
            }

        }
    }

}


void ask()
{
    int op;
    cout<<"Do you want to continue?\n1.Yes\n2.No";
    cin>>op;
    switch(op)
    {
    case 1:
        display();
        break;

    case 2:
        cout<<"THanking You\n";
        break;
    }


}
void display()
{
    int op;

    cout<<"\n\t\t\tMy Divisions are..:\n\n";
    cout<<"\t\t\t\t1.Snacks\n\t\t\t\t2.Stationery\n\t\t\t\t3.Cosmetics\n\t\t\t\t4.Groceries\n\t\t\t\t5.Others\n";
    cout<<"Select your option:\n";
    cin>>op;

    switch(op)
    {
    case 1:
        snacks();
        break;
    case 2:
        stationery();
        break;
    case 3:
        cosmetics();
        break;

    case 4:
        groceries();
        break;
    case 5:
        others();
        break;


    }

}
int main()
{
    cout<<"\t\t\t*******************************"<<endl;
    cout<<"\t\t\tWelcome to our Department Store"<<endl;
    cout<<"\t\t\t*******************************"<<endl;
    display();

    cout<<"   items\t\tquantity\t\tamount\n";

    for(int i=1;i<=45;i++){

    cout<<c[i].items<<"\t\t ";
    cout<<c[i].quantity<<"\t\t ";
    cout<<c[i].amount<<"\t\t\n ";
    }
    cout<<"Total Purchasing amount:"<<purchase<<endl;


}
